# gitworkshop2019
Pre-FOSSMeet Git Workshop at NIT-C
